function test() {
    const obj = {}
    obj.comment = 'this is an object'
    console.log(obj.comment)

    function func() {
        console.log(456)
    }
    func()
    func.comment = 'functions are also objects in JS'
    console.log(func.comment)
}

test()