function test() {
    const obj = {
        loop: 'цикл',
        event: 'событие',
        array: 'массив',
    }
    // console.log(obj)
    // for (const key of Object.keys(obj)) {
    //     console.log(key)
    // }
    for (const value of Object.values(obj)) {
        console.log(value)
    }
}

test()
