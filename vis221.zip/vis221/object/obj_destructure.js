function test() {
    const obj = {
        name: 'Petya',
        age: 40,
    }
    console.log(obj)
    console.log(obj.name, obj.age)
    const {name, age} = obj
    console.log(name, age)
}

test()