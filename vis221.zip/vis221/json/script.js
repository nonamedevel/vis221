/*
    JSON - JavaScript Object Notation
*/

function test1() {
    const users = [
        { id: 1, name: 'Vasya', age: 30, premium: false },
        { id: 2, name: 'Masha', age: 20, premium: false },
        { id: 3, name: 'Mark', age: 40, premium: true },
    ]
    // console.log(`Masha is ${users[1].age} years old.`)
    // console.log(`Mark is a ${users[2].premium ? 'VIP' : 'free'} user.`)

    const str = JSON.stringify(users)
    // console.log(str)
    // console.log(typeof str)
    console.log(`Masha is ${str.slice(79, 81)} years old.`)
    console.log(str.slice(140, 144))
    console.log(typeof str.slice(140, 144))
    console.log(`Mark is a ${str.slice(140, 144) === 'true' ? 'VIP' : 'free'} user.`)
}

function test() {
    const str = `[
        {"id":1,"name":"Vasya","age":30,"premium":false},
        {"id":2,"name":"Masha","age":20,"premium":false},
        {"id":3,"name":"Mark","age":40,"premium":true}
    ]`
    const users = JSON.parse(str)
    console.log(users)

    console.log(`Masha is ${users[1].age} years old.`)
    console.log(`Mark is a ${users[2].premium ? 'VIP' : 'free'} user.`)
}

test()
