/*
    https://www.npmjs.com/package/ws
    https://github.com/websockets/ws
*/

const { WebSocketServer } = require('C:/ws/index.js')

const wss = new WebSocketServer({ port: 8080 })

const socketToUserName = new Map()
const connections = []
wss.on('connection', function(ws) {
    connections.push(ws)

    ws.on('error', console.error)

    ws.on('message', function(data) {
        message = JSON.parse(data)
        if (message.type === 'user_name') {
            socketToUserName.set(ws, message.data)
        } else if (message.type === 'text_message') {
            for (const socket of connections) {
                socket.send(JSON.stringify({
                    type: 'text_message',
                    data: message.data,
                    user: socketToUserName.get(ws),
                }))
            }
        } else {

        }
    })
})
