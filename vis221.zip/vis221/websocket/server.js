/*
    https://www.npmjs.com/package/ws
    https://github.com/websockets/ws
*/

const { WebSocketServer } = require('C:/ws/index.js')
const fs = require('fs')
let users
fs.readFile('C:/vis221/websocket/users.json', (err, data) => {
    if (err) throw err
    users = JSON.parse(data)
    console.log(users)
})

const wss = new WebSocketServer({ port: 8080 })

const socketToUserName = new Map()
wss.on('connection', function(ws) {
    socketToUserName.set(ws, null)
    console.log(socketToUserName.size)

    ws.on('error', console.error)

    ws.on('close', () => {
        socketToUserName.delete(ws)
        console.log(socketToUserName.size)
    })

    ws.on('message', function(data) {
        const messageObj = JSON.parse(data)
        if (messageObj.type === 'user_name') {
            socketToUserName.set(ws, messageObj.data)
            let user
            for (const item of users) {
                if (item.id === messageObj.data) {
                    user = item
                    break
                }
            }
            if (!user) {
                user = {id: messageObj.data, contacts: []}
                users.push(user)
            }
            ws.send(JSON.stringify({
                type: 'contacts_list',
                data: user.contacts,
            }))
        } else if (messageObj.type === 'text_message') {
            const userName = socketToUserName.get(ws)
            for (const socket of socketToUserName.keys()) {
                socket.send(JSON.stringify({
                    type: 'text_message',
                    data: messageObj.data,
                    user: userName,
                }))
            }
        } else {

        }
    })
})
