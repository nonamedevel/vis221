/*
    https://www.npmjs.com/package/ws
    https://github.com/websockets/ws
*/

const { WebSocketServer } = require('C:/ws/index.js')
const fs = require('fs')
let users
fs.readFile('C:/vis221/websocket/users.json', (err, data) => {
    if (err) throw err
    users = JSON.parse(data)
    console.log(users)
})

const wss = new WebSocketServer({ port: 8080 })

const socketToUserName = new Map()
const userNameToSocket = new Map()
const pendingMessages = new Map()
wss.on('connection', function(ws) {
    socketToUserName.set(ws, null)
    console.log(socketToUserName.size)

    ws.on('error', console.error)

    ws.on('close', () => {
        const userName = socketToUserName.get(ws)
        userNameToSocket.delete(userName)
        socketToUserName.delete(ws)
        console.log(socketToUserName.size)
    })

    ws.on('message', function(data) {
        const messageObj = JSON.parse(data)
        if (messageObj.type === 'user_name') {
            const userName = messageObj.data
            socketToUserName.set(ws, userName)
            userNameToSocket.set(userName, ws)
            if (pendingMessages.has(userName)) {
                const messages = pendingMessages.get(userName)
                console.log(messages)
            }
            let user
            for (const item of users) {
                if (item.id === userName) {
                    user = item
                    break
                }
            }
            if (!user) {
                user = {id: userName, contacts: []}
                users.push(user)
            }
            ws.send(JSON.stringify({
                type: 'contacts_list',
                data: user.contacts,
            }))
        } else if (messageObj.type === 'text_message') {
            const senderName = socketToUserName.get(ws)
            console.log(messageObj)
            const receiverName = messageObj.user
            const socket = userNameToSocket.get(receiverName)
            if (socket) {
                socket.send(JSON.stringify({
                    type: 'text_message',
                    data: messageObj.data,
                    user: senderName,
                }))
            } else {
                addPendingMessage(receiverName, {
                    type: 'text_message',
                    data: messageObj.data,
                    user: senderName,
                })
            }
        } else {

        }
    })
})

function addPendingMessage(receiverName, messageObj) {
    if (pendingMessages.has(receiverName)) {
        const arr = pendingMessages.get(receiverName)
        arr.push(messageObj)
    } else {
        const arr = [messageObj]
        pendingMessages.set(receiverName, arr)
    }
}
