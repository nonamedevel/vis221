function test() {
    const nameInput = document.querySelector('.name_input')
    nameInput.value = 'masha'
    const startChatButton = document.querySelector('.start_chat')
    setTimeout(() => {
        startChatButton.click()
    }, 100)
}

// test()
