function test1() {
    setTimeout(function() {
        document.body.style.background = 'black'
    }, 2000)
}

function test1() {
    setInterval(function() {
        if (document.body.style.background === 'black') {
            document.body.style.background = ''
        } else {
            document.body.style.background = 'black'
        }
    }, 1000)
}

function test() {
    let counter = 0
    const intervalId = setInterval(function() {
        if (document.body.style.background === 'black') {
            document.body.style.background = ''
        } else {
            document.body.style.background = 'black'
        }
        counter++
        if (counter < 4) {
            return
        }
        clearInterval(intervalId)
    }, 1000)
}

test()
