const users = [
    {
        name: 'Vasya',
        balance: 0,
    },
    {
        name: 'Masha',
        balance: 0,
    },
]
let winnerId
const winnerElem = document.querySelector('.winner')
function selectWinner() {
    return 0
}
function transferMoney() {
    return new Promise(function(res, rej) {
        setTimeout(function() {
            users[winnerId].balance = 1000
            res()
        }, 100)
    })
}

async function main() {
    try {
        winnerId = selectWinner()
        await transferMoney()
        const winner = users[winnerId]
        winnerElem.innerHTML = `Congrats ${winner.name},<br>
        your balance is ${winner.balance}`
    } catch (err) {
        console.log(err)
    }
}
main()


