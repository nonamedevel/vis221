setTimeout(() => {
    winnerId = 1
}, 50)