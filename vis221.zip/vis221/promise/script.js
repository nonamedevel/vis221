function test1() {
    const promise = new Promise(function(res, rej) {
        res(123)
    })
    console.log(promise)
    // console.log(promise + 27)
}

function test1() {
    const promise = new Promise(function(res, rej) {
        res(123)
    })
    promise.then((result) => {
        console.log(result)
        console.log(result + 27)
    })
}

function test1() {
    const promise = new Promise(function(res, rej) {
        rej(456)
    })
    promise.then((result) => {
        console.log(result)
    }).catch((err) => {
        console.log(err)
    })
}

function test1() {
    const promise = new Promise(function(res, rej) {
        setTimeout(function() {
            res(123)
        }, 3000)
    })
    promise.then((result) => {
        console.log(result + 77)
    }).catch((err) => {
        console.log(err)
    })
}

function test() {
    function asyncTask() {
        return new Promise(function(res, rej) {
            setTimeout(function() {
                res(123)
            }, 3000)
        })
    }
    asyncTask().then((result) => {
        console.log(result)
    }).catch((err) => {
        console.log(err)
    })
}

test()
