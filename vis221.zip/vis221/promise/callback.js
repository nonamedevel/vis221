function test1() {
    function printInfo(name, age) {
        console.log(name, age)
    }
    printInfo('Vasya', 33)
}

function test1() {
    function printInfo(callback) {
        const {name, age} = callback()
        console.log(name, age)
    }
    function generateInfo() {
        return {
            name: 'Masha',
            age: 23,
        }
    }
    printInfo(generateInfo)
}

function test1() {
    function printInfo(callback) {
        const {name, age} = callback()
        console.log(name, age)
    }
    printInfo(function() {
        return {
            name: 'Petya',
            age: 40,
        }
    })
}

function test1() {
    function printInfo(callback) {
        const {name, age} = callback()
        console.log(name, age)
    }
    printInfo(() => {
        return {
            name: 'Ira',
            age: 50,
        }
    })
}

function test() {
    function printInfo(callback) {
        const {name, age} = callback()
        console.log(name, age)
    }
    printInfo(() => ({
        name: 'Jack',
        age: 20,
    }))
}

test()
