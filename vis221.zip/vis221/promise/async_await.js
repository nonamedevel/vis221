function test() {
    function asyncTask() {
        return new Promise(function(res, rej) {
            setTimeout(function() {
                res(123)
            }, 3000)
        })
    }
    async function main() {
        try {
            console.log('start')
            // something else is happening
            const result = await asyncTask()
            console.log(result)
        } catch (err) {
            console.log(err)
        }
        console.log('end')
    }
    main()

    // asyncTask().then((result) => {
    //     console.log(result)
    // }).catch((err) => {
    //     console.log(err)
    // })
}

test()
