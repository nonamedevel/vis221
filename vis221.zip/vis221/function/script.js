function test1() {
    function funcDeclExample() {
        console.log('function declaration')
    }
    funcDeclExample()
    const funcExprExample = function() {
        console.log('function expression')
    }
    funcExprExample()
}

function test1() {
    const arrowFunc1 = () => {
        console.log('arrow function 1')
    }
    const arrowFunc2 = () => console.log('arrow function 2')
    arrowFunc2()
}

function test() {
    function printInfo(name, age) { // parameters
        console.log(name, age)
    }
    printInfo('Vasya', 30) // arguments
}

test()