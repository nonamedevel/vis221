function test1() {
    for (let i = 0; i < 5; i++) {
        console.log(i)
    }
    console.log(i)
}

function test() {
    let i = 10
    while (i < 15) {
        console.log(i)
        i++
    }
    // console.log(i)
}

function test1() {
    for (let i = 4; i >= 0; i--) {
        console.log(i)
    }
}

function test1() {
    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December',
    ]
    for (const month of months) {
        console.log(month)
    }
}

function test1() {
    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December',
    ]
    // for (let month of months) {
    //     month = month.toLowerCase()
    //     console.log(month)
    // }
    for (let i = 0; i < months.length; i++) {
        months[i] = months[i].toLowerCase()
    }
    console.log(months)
}

test()