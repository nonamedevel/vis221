const fs = require('fs')

function test1() {
    fs.writeFile('hello.txt', "Let's use a relative path this time", (err) => {
        if (err) throw err
        console.log('done')
    })
}

function test() {
    fs.readFile('hello.txt', 'utf8', (err, data) => {
        if (err) throw err
        console.log(data)
    })
}

test()
