const http = require('node:http')
const fs = require('node:fs')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]

const routes = {}

routes['/'] = (req, res) => handleStaticResource(res, 'index.html')
routes['/index.html'] = (req, res) => handleStaticResource(res, 'index.html')
routes['/login.html'] = (req, res) => handleStaticResource(res, 'login.html')

routes['/admin.html'] = function(req, res) {
    const queryString = req.url.split('?')[1]
    if (!queryString) {
        handleStaticResource(res, '404.html', 404)
        return
    }
    const token = queryString.split('=')[1]
    if (token === '12345') {
        handleStaticResource(res, 'admin.html')
    } else {
        handleStaticResource(res, '404.html', 404)
    }
}

function handleStaticResource(res, fileName, statusCode = 200) {
    fs.readFile(fileName, function(err, data) {
        res.writeHead(statusCode, { 'Content-Type': 'text/html' })
        res.end(data)
    })
}

const server = http.createServer(function(req, res) {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    const url = req.url.split('?')[0]
    if (routes[url]) {
        routes[url](req, res)
    } else {
        handleStaticResource(res, '404.html', 404)
    }
})

server.listen(8000)