const http = require('node:http')

const server = http.createServer(function(req, res) {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({
        num: Math.random(),
    }))
})

server.listen(8000)