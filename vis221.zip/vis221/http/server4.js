const http = require('node:http')
const fs = require('node:fs')

const unwantedRoutes = [
    '/.well-known/appspecific/com.chrome.devtools.json',
    '/favicon.ico',
]

const server = http.createServer(function(req, res) {
    if (!unwantedRoutes.includes(req.url)) {
        console.log(req.url)
    }
    if (req.url === '/') {
        fs.readFile('C:/vis221/http/index.html', function(err, data) {
            res.writeHead(200, { 'Content-Type': 'text/html' })
            res.end(data)
        })
    } else {
        fs.readFile('C:/vis221/http/404.html', function(err, data) {
            res.writeHead(404, { 'Content-Type': 'text/html' })
            res.end(data)
        })
    }
})

server.listen(8000)