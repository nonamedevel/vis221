const counterElem = document.querySelector('.counter')
const startButton = document.querySelector('.start')
const stopButton = document.querySelector('.stop')
const resetButton = document.querySelector('.reset')

let counter = 0
// let counter = 3595
// let counter = 359995
let intervalId

function heavyComputation() {
    let sum = 0
    for (let i = 0; i < 1000000000; i++) {
        const randNumber = Math.random()
        if (randNumber < 0.1) {
            sum += randNumber
        }
    }
    console.log(sum)
}

function updateDisplay() {
    if (counter === 360000) {
        counter = 0
        // resetCounter()
    }
    formatTime(counter)
    heavyComputation()
}

function formatTime(seconds) {
    // const hours = Math.floor(seconds / 3600)
    const hours = (seconds - seconds % 3600) / 3600
    seconds -= hours * 3600
    const hoursStr = String(hours).padStart(2, '0')

    // const minutes = Math.floor(seconds / 60)
    const minutes = (seconds - seconds % 60) / 60
    seconds -= minutes * 60
    const minutesStr = String(minutes).padStart(2, '0')

    const secondsStr = String(seconds).padStart(2, '0')

    counterElem.textContent = `${hoursStr}:${minutesStr}:${secondsStr}`
}
updateDisplay()

function startCounter() {
    intervalId = setInterval(function() {
        counter++
        updateDisplay()
    }, 1000)

    startButton.disabled = true
    stopButton.disabled = false
    resetButton.disabled = false
}
startButton.addEventListener('click', startCounter)

function stopCounter() {
    clearInterval(intervalId)

    startButton.disabled = false
    stopButton.disabled = true
    resetButton.disabled = true
}
stopButton.addEventListener('click', stopCounter)

function resetCounter() {
    clearInterval(intervalId)
    counter = 0
    updateDisplay()

    startButton.disabled = false
    stopButton.disabled = true
    resetButton.disabled = true
}
resetButton.addEventListener('click', resetCounter)
