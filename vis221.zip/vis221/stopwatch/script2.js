const counterElem = document.querySelector('.counter')
const startButton = document.querySelector('.start')
const stopButton = document.querySelector('.stop')
const resetButton = document.querySelector('.reset')

let startTime = 0
let elapsedTime = 0
let intervalId

function heavyComputation() {
    let sum = 0
    for (let i = 0; i < 1000000000; i++) {
        const randNumber = Math.random()
        if (randNumber < 0.1) {
            sum += randNumber
        }
    }
    console.log(sum)
}

function updateElapsedTime() {
    const currentTime = +new Date()
    elapsedTime += currentTime - startTime
    console.log(currentTime, startTime, elapsedTime)
    startTime = currentTime
}

function updateDisplay() {
    updateElapsedTime()
    if (elapsedTime > 360000000) {
        resetTimer()
    }
    // heavyComputation()
    setTime(elapsedTime)
}

function setTime(ms) {
    const timeString = formatTime(ms)
    counterElem.textContent = timeString
}

function formatTime(ms) {
    let seconds = Math.floor(ms / 1000)
    // let seconds = Math.round(ms / 1000)

    // const hours = Math.floor(seconds / 3600)
    const hours = (seconds - seconds % 3600) / 3600
    seconds -= hours * 3600
    const hoursStr = String(hours).padStart(2, '0')

    // const minutes = Math.floor(seconds / 60)
    const minutes = (seconds - seconds % 60) / 60
    seconds -= minutes * 60
    const minutesStr = String(minutes).padStart(2, '0')

    const secondsStr = String(seconds).padStart(2, '0')

    return `${hoursStr}:${minutesStr}:${secondsStr}`
}
setTime(0)

function startTimer() {
    startTime = +new Date()

    intervalId = setInterval(updateDisplay, 1000)

    startButton.disabled = true
    stopButton.disabled = false
    resetButton.disabled = false
}
startButton.addEventListener('click', startTimer)

function stopTimer() {
    clearInterval(intervalId)
    updateElapsedTime()

    startButton.disabled = false
    stopButton.disabled = true
    resetButton.disabled = true
}
stopButton.addEventListener('click', stopTimer)

function resetTimer() {
    clearInterval(intervalId)
    setTime(0)
    startTime = 0

    startButton.disabled = false
    stopButton.disabled = true
    resetButton.disabled = true
}
resetButton.addEventListener('click', resetTimer)
