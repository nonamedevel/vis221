const counterElem = document.querySelector('.counter')
const startButton = document.querySelector('.start')
const stopButton = document.querySelector('.stop')
let counter = 0
let intervalId
startButton.addEventListener('click', function() {
    intervalId = setInterval(function() {
        counter++
        counterElem.textContent = counter
    }, 1000)
})
stopButton.addEventListener('click', function() {
    clearInterval(intervalId)
})
