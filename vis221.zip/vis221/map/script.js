function test1() {
    const map = new Map()
    map.set('computer', 'компьютер')
    map.set('keyboard', 'клавиатура')
    map.set('monitor', 'монитор')
    console.log(map)
    console.log(map.size)
}

function test1() {
    const map = new Map([
        ['computer', 'компьютер'],
        ['keyboard', 'клавиатура'],
        ['monitor', 'монитор'],
        ['mouse', 'мышь'],
    ])
    console.log(map)
    console.log(map.size)
}

function test1() {
    const map = new Map([
        ['computer', 'компьютер'],
        ['keyboard', 'клавиатура'],
        ['monitor', 'монитор'],
        ['mouse', 'мышь'],
    ])
    for (const item of map) {
        console.log(item)
    }
}

function test1() {
    const map = new Map([
        ['computer', 'компьютер'],
        ['keyboard', 'клавиатура'],
        ['monitor', 'монитор'],
        ['mouse', 'мышь'],
    ])
    console.log(map.get('keyboard'))
}

function test1() {
    const map = new Map([
        ['computer', 'компьютер'],
        ['keyboard', 'клавиатура'],
        ['monitor', 'монитор'],
        ['mouse', 'мышь'],
    ])
    map.delete('keyboard')
    map.delete('mouse')
    console.log(map)
}

function test1() {
    const map = new Map([
        [{id: 1}, 'компьютер'],
        [{id: 2}, 'клавиатура'],
        [{id: 3}, 'монитор'],
        [{id: 4}, 'мышь'],
    ])
    console.log(map)
}

function test() {
    const obj = {}
    obj[{id: 1}] = 'компьютер'
    obj[{id: 2}] = 'клавиатура'
    obj[{id: 3}] = 'монитор'
    obj[{id: 4}] = 'мышь'
    console.log(obj)
}

test()
