
// src\vs\base\browser\ui\table\tableWidget.ts
class ColumnHeader { // 121
    constructor(column, index) {
        this.element = document.createElement('div')
        this.element.classList.add('monaco-table-th')
        this.element.textContent = column.label
    }
}

class Table {
    constructor(user, container, virtualDelegate, columns, renderers) { // 193
        const headers = []
        for (let i = 0; i < columns.length; i++) {
            headers.push(new ColumnHeader(columns[i], i))
        }

        this.domNode = document.createElement('div')
        this.domNode.classList.add('monaco-table')
        container.append(this.domNode)

        const monacoSplitView2 = document.createElement('div')
        monacoSplitView2.classList.add('monaco-split-view2')
        this.domNode.append(monacoSplitView2)

        const splitViewContainer = document.createElement('div')
        splitViewContainer.classList.add('split-view-container')
        monacoSplitView2.append(splitViewContainer)

        for (const item of headers) {
            const splitViewView = document.createElement('div')
            splitViewView.classList.add('split-view-view')
            splitViewContainer.append(splitViewView)

            splitViewView.append(item.element)
        }
    }
}

const columns = [
    {label: ''},
    {label: 'Command'},
    {label: 'Keybinding'},
    {label: 'When'},
    {label: 'Source'},
]

const keybindingsBody = document.createElement('div')
keybindingsBody.classList.add('keybindings-body')
document.body.append(keybindingsBody)

const keybindingsTableContainer = document.createElement('div')
keybindingsTableContainer.classList.add('keybindings-table-container')
keybindingsBody.append(keybindingsTableContainer)

const table = new Table(undefined, keybindingsTableContainer, undefined, columns)

