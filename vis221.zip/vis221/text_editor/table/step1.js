

const keybindingsBody = document.createElement('div')
keybindingsBody.classList.add('keybindings-body')
document.body.append(keybindingsBody)

const keybindingsTableContainer = document.createElement('div')
keybindingsTableContainer.classList.add('keybindings-table-container')
keybindingsBody.append(keybindingsTableContainer)

const monacoTable = document.createElement('div')
monacoTable.classList.add('monaco-table')
keybindingsTableContainer.append(monacoTable)

const monacoSplitView2 = document.createElement('div')
monacoSplitView2.classList.add('monaco-split-view2')
monacoTable.append(monacoSplitView2)

const splitViewContainer = document.createElement('div')
splitViewContainer.classList.add('split-view-container')
monacoSplitView2.append(splitViewContainer)

const items = [
    'Command',
    'Keybinding',
    'When',
    'Source',
]
for (const item of items) {
    const splitViewView = document.createElement('div')
    splitViewView.classList.add('split-view-view')
    splitViewContainer.append(splitViewView)
    
    const monacoTableTh = document.createElement('div')
    monacoTableTh.classList.add('monaco-table-th')
    monacoTableTh.textContent = item
    splitViewView.append(monacoTableTh)
}
