class ArithmeticWidget {
    constructor() {
        this.data = [
            {
                name: 'magic',
                bytes: [
                    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 
                ],
            },
            {
                name: 'type',
                bytes: [
                    0x01, 0x07, 0x01,
                        0x60, 0x02, 0x7d, 0x7d, 0x01, 0x7d, 
                ],
            },
            {
                name: 'function',
                bytes: [
                    0x03, 0x02, 0x01, 0x00,
                ],
            },
            {
                name: 'export',
                bytes: [
                    0x07, 0x07, 0x01,
                        0x03, 0x61, 0x62, 0x63, 0x00, 0x00, 
                ],
            },
            {
                name: 'code',
                bytes: [
                    0x0a, 0x09, 0x01,
                        0x07, 0x00, 
                            0x20, 0x00, 
                            0x20, 0x01, 
                            0x92, 
                        0x0b,
                ],
            },
        ]
        this.bytes = []

        const widgetElem = document.querySelector('.arithmetic_widget')

        const modeElem = widgetElem.querySelector('.mode')
        modeElem.addEventListener('click', this.onModeClick.bind(this))

        const runButton = widgetElem.querySelector('.run')
        runButton.addEventListener('click', this.onContentClick.bind(this))

        this.resultInput = widgetElem.querySelector('.result')

        const contentElem = widgetElem.querySelector('.content')
        for (const item of this.data) {
            this.bytes.push(...item.bytes)
            for (const byte of item.bytes) {
                const byteElem = document.createElement('div')
                byteElem.classList.add('byte')
                byteElem.classList.add(item.name)
                byteElem.textContent = byte.toString(16).padStart(2, '0')
                contentElem.append(byteElem)
            }
        }
        
        const legendElem = widgetElem.querySelector('.legend')
        for (const item of this.data) {
            const rowElem = document.createElement('div')
            rowElem.classList.add('row')
            legendElem.append(rowElem)

            const colorElem = document.createElement('div')
            colorElem.classList.add('color')
            colorElem.classList.add(item.name)
            rowElem.append(colorElem)

            const nameElem = document.createElement('div')
            nameElem.classList.add('name')
            nameElem.textContent = item.name
            rowElem.append(nameElem)
        }
    }
    onModeClick(event) {
        console.log(event.target)
    }
    onContentClick() {
        WebAssembly.instantiate(new Uint8Array(this.bytes)).then(({instance}) => {
            this.resultInput.value = instance.exports.abc(3.5, 1.5)
        })
    }
}

const arithmeticWidget = new ArithmeticWidget()
