function test() {
    function printInfo(name, age) {
        console.log(`Hi. My name is ${name}. I'm ${age}.`)
    }
    printInfo('Vasya', 30)
}

test()