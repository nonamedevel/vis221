function test1() {
    console.log(Math.random())
}

function test1() {
    console.log(Math.random() * 100000)
}

function test1() {
    console.log(Math.floor(0.9999999 * 100000))
    // console.log(Math.floor(Math.random() * 100000))
}

/*
    0 - 9
    5 - 14
*/
function test1() {
    console.log(Math.floor(Math.random() * 10) + 5)
}

function test() {
    const obj = {}
    for (let i = 0; i < 1000000; i++) {
        const rand = Math.floor(Math.random() * 10) + 5
        if (obj[rand]) {
            obj[rand]++
        } else {
            obj[rand] = 1
        }
    }
    console.log(obj)
}

test()
