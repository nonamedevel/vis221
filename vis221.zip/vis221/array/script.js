function test1() {
    const months = [
        'January', 'February', 'March', 'April', 'May', 'June', 
        'July', 'August', 'September', 'October', 'November', 'December',
    ]

    const fall = months.slice(8, 11)
    // console.log(fall)
    // // console.log(fall.includes('April'))
    // // console.log(fall.includes('November'))
    console.log(fall.includes('october'))
}

function test1() {
    function isFall(month) {
        month = month.toLowerCase()
        const months = [
            'January', 'February', 'March', 'April', 'May', 'June', 
            'July', 'August', 'September', 'October', 'November', 'December',
        ]
        for (let i = 0; i < months.length; i++) {
            months[i] = months[i].toLowerCase()
        }
        const fall = months.slice(8, 11)
        return fall.includes(month)
    }

    console.log(isFall('October'))
    console.log(isFall('october'))
}

function test() {
    function isFall1(month) {
        const fall = ['september', 'october', 'november']
        month = month.toLowerCase()
        return fall.includes(month)
    }

    function isFall(month) {
        month = month.toLowerCase()
        return month === 'september' || month === 'october' || month === 'november'
    }

    console.log(isFall('October'))
    console.log(isFall('october'))
    console.log(isFall('May'))
}

test()
